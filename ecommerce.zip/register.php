<?php 

session_start();
if(isset($_SESSION['auth']))
{
    $_SESSION['message'] = "Already login";
    header('Location: index.php');
    exit();
}
include('includes/header.php'); 
?>
    <div class="py-5">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-6">
                    <?php
                    if(isset($_SESSION['message']))
                    {
                        ?>
                        <div class="alert alert-warning alert-dismissible fade show" role="alert">
                            <strong>Hey!</strong> <?=$_SESSION['message']; ?>.
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <?php
                        unset($_SESSION['message']);
                    }
                    ?>
                    <div class="card">
                        <div class="card-header">
                            <h1>Register form</h1>
                        </div>
                        <div class="card-body">
                            <form action="functions/authcode.php" method="POST">
                                <div class="m-3">
                                    <label class="form-label">Name</label>
                                    <input type="text" name="name" class="form-control" placeholder="Enter your name">
                                </div>
                                <div class="m-3">
                                    <label class="form-label">Phone</label>
                                    <input type="number" name="phone" class="form-control" placeholder="Enter your phone number">
                                </div>
                                <div class="m-3">
                                    <label for="exampleInputEmail1">Email address</label>
                                    <input type="email" name="email" class="form-control" placeholder="Enter your email" id="exampleInputEmail1" aria-describedby="emailHelp">
                                </div>
                                <div class="m-3">
                                    <label for="exampleInputPassword1">Password</label>
                                    <input type="password" name="password" class="form-control" placeholder="Enter password" id="exampleInputPassword1">
                                </div>
                                <div class="m-3">
                                    <label for="exampleInputPassword1">Confirm Password</label>
                                    <input type="password" name="cpassword" class="form-control" placeholder="Confirm password" id="exampleInputPassword1">
                                </div>
                                <div class="m-3">
                                    <button type="submit" name="register_btn" class="btn btn-primary">Submit</button>
                                </div>
                                
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php include('includes/footer.php'); ?>
    